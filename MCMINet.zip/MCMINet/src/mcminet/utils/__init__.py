"""Public utility namespace."""
